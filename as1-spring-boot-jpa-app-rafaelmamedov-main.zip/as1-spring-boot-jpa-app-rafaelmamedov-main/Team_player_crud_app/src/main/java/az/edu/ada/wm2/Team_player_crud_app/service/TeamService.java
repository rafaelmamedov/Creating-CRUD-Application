package az.edu.ada.wm2.Team_player_crud_app.service;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import org.springframework.data.domain.Page;

import java.util.List;

public interface TeamService {

    List<Team> list();

    Page<Team> list(int pageNo);


    Team save(Team team);
    Team getById(Long id);

    void deleteById(Long id);
    List<Team> getTeamByNamesAnd(String name, String country, String liga, String trainer, Long marketvalue, Long totalcups);

    List<Team> getAllTeams(String keyword);
    List<Team> getAllCupsMarket();
    List<Team> getAllTeamstrainer(String keyword);
    List<Team> getAllMarketValue(String keyword);
    List<Team> getAllCountryMarketValue(String keyword);


}
