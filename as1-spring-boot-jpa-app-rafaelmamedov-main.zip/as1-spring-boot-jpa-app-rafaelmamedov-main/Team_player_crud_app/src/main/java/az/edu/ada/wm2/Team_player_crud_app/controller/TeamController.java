package az.edu.ada.wm2.Team_player_crud_app.controller;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import az.edu.ada.wm2.Team_player_crud_app.service.PlayerService;
import az.edu.ada.wm2.Team_player_crud_app.service.TeamService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@Controller
@RequestMapping("/team")

public class TeamController {
    static final Logger LOGGER = LoggerFactory.getLogger(TeamController.class);



    private TeamService teamService;

    public TeamController(TeamService teamService)  {
        this.teamService = teamService;}



    @GetMapping({"", "/", "/list"})
    public String getTeams(Model model) {
        return getTeamsByPageNo(model, 1);
    }
    @GetMapping("/page/{no}")
    public String getTeamsByPageNo(Model model, @PathVariable("no") Integer pageNo) {
        Page<Team> teamsPage = teamService.list(pageNo);

        model.addAttribute("team", teamsPage.getContent());
        model.addAttribute("currentPage", pageNo);
        model.addAttribute("totalPages", teamsPage.getTotalPages());
        model.addAttribute("nbElements", teamsPage.getNumberOfElements());
        model.addAttribute("totalElements", teamsPage.getTotalElements());

        return "team/index";
    }

    @GetMapping("/newTeam")
    public String createNewTeam(Model model) {
        model.addAttribute("team", new Team());
        return "team/new_team";
    }
    @PostMapping("/")
    public String save(@ModelAttribute("team") Team team) {
        teamService.save(team);
        return "redirect:/team/";
    }
    @GetMapping("/{id}")
    public String getById(Model model, @PathVariable Long id) {
        model.addAttribute("team", teamService.getById(id));
        return "team/info";
    }

    @GetMapping("/delete/{id}")
    public String deleteTeam(@PathVariable Long id) {
        teamService.deleteById(id);
        return "redirect:/team/";
    }

    @GetMapping("/update/{id}")
    public ModelAndView updateTeam(@PathVariable Long id) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("team/update");
        mv.addObject("team", teamService.getById(id));
        return mv;
    }
    @GetMapping("/filter/{keyword}")
    public String getTeamstrainerwithkeyword(Model model, @PathVariable String keyword){
        model.addAttribute("team", teamService.getAllTeams(keyword));

        return "team/index";
    }
    @GetMapping("/cupsmarket")
    public String getCupsMarket(Model model){
        model.addAttribute("team", teamService.getAllCupsMarket());

        return "team/index";
    }
    @GetMapping("/filtertrainer/{keyword}")
    public String getTeamstrainerwithmo(Model model, @PathVariable String keyword){
        model.addAttribute("team", teamService.getAllTeamstrainer(keyword));

        return "team/index";
    }
    @GetMapping("/market/{keyword}")
    public String getMarketValue(Model model, @PathVariable String keyword){
        model.addAttribute("team", teamService.getAllMarketValue(keyword));

        return "team/index";
    }
    @GetMapping("/countrymarket/{keyword}")
    public String getCountryMarketValue(Model model, @PathVariable String keyword){
        model.addAttribute("team", teamService.getAllCountryMarketValue(keyword));

        return "team/index";
    }
    @GetMapping("/and/{name}/{country}/{liga}/{trainer}/{marketvalue}/{totalcups}")
    public String getTeamByNameAnd(Model model, @PathVariable String name, @PathVariable String country,@PathVariable String liga,@PathVariable String trainer,@PathVariable Long marketvalue,@PathVariable Long totalcups) {

        var team = teamService.getTeamByNamesAnd(name,country,liga,trainer,marketvalue,totalcups);

        model.addAttribute("team",team);

        return "team/index";
    }

}

