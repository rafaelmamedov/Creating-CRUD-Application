package az.edu.ada.wm2.Team_player_crud_app.service.impl;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;

import java.util.List;

import az.edu.ada.wm2.Team_player_crud_app.repository.TeamRepository;
import az.edu.ada.wm2.Team_player_crud_app.service.TeamService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;



@Service
public class TeamServiceİmpl implements TeamService {

    TeamRepository teamRepo;

    public TeamServiceİmpl(TeamRepository teamRepo) {
        this.teamRepo = teamRepo;
    }

    @Override
    public Page<Team> list(int pageNo) {
        Pageable pageable = PageRequest.of(pageNo - 1, 5,
                Sort.by("name").and(Sort.by("trainer").and(Sort.by("totalcups").and(Sort.by("marketvalue").and(Sort.by("country")).and(Sort.by("liga"))))));
        return teamRepo.findAll(pageable);
    }

    @Override
    public List<Team> list() {
        return (List<Team>) teamRepo.findAll();
    }


    @Override
    public Team save(Team team) {
        return teamRepo.save(team);
    }

    @Override
    public Team getById(Long id) {
        return teamRepo.findById((id)).orElse(null);
    }

    @Override
    public void deleteById(Long id) {
        teamRepo.deleteById(id);
    }
    public List<Team> getTeamByNamesAnd(String name, String country, String liga, String trainer, Long marketvalue, Long totalcups) {
        return (List<Team>) teamRepo.findByNameAndCountryAndLigaAndTrainerAndMarketvalueAndTotalcups(name, country, liga, trainer, marketvalue,totalcups);

    }
    public List<Team> getAllTeams(String keyword) {
        return (List<Team>) teamRepo.getAllTeamsUsingJPAQuery(keyword);
    }
    public List<Team> getAllCupsMarket() {return (List<Team>) teamRepo.getAllCupsMarketUsingJPAQuery();
    }

    public List<Team> getAllTeamstrainer(String keyword) {
        return (List<Team>) teamRepo.getAllTeamsUsingNativeQuery();
    }
    public List<Team> getAllMarketValue(String keyword){return (List<Team>) teamRepo.getMarketValueUsingNativeQuery();
    }
    public List<Team> getAllCountryMarketValue(String keyword){return (List<Team>) teamRepo.getCountryANDMarketValueUsingNativeQuery();
    }
}