package az.edu.ada.wm2.Team_player_crud_app.service.impl;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import az.edu.ada.wm2.Team_player_crud_app.repository.PlayerRepository;
import az.edu.ada.wm2.Team_player_crud_app.repository.TeamRepository;
import az.edu.ada.wm2.Team_player_crud_app.service.PlayerService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;



    @Service
    public class PlayerServiceİmpl implements PlayerService {

        private PlayerRepository playerRepo;

        private TeamRepository teamRepo;

        public PlayerServiceİmpl(PlayerRepository playerRepo, TeamRepository teamRepo) {
            this.playerRepo = playerRepo;
            this.teamRepo = teamRepo;
        }

        @Override
        public Page<Player> list(int pageNo) {
            Pageable pageable = PageRequest.of(pageNo - 1, 5,
            Sort.by("age").and(Sort.by("firstname").and(Sort.by("lastname").and(Sort.by("height").and(Sort.by("position").and(Sort.by("contactmail")))))));
            return playerRepo.findAll(pageable);
        }

        @Override
        public Player save(Player player) {
            return playerRepo.save(player);
        }

        @Override
        public Player getById(Long id) {
            return playerRepo.findById(id).orElse(null);
        }
        @Override
        public void deleteById(Long id) {
            playerRepo.deleteById(id);}

        public List<Player> getPlayerByNamesAnd(String firstname, String lastname, String contactmail, String age, Long height, String position) {
            return (List<Player>) playerRepo.findByFirstnameAndLastnameAndContactmailAndAgeAndHeightAndPosition(firstname, lastname, contactmail,  age,  height,position);

        }
        public List<Player> getPlayerByFirstnames(String firstname) {
            return (List<Player>) playerRepo.findByFirstnameLike(firstname);

        }



        public List<Player> getPlayerByNamesOr(String firstname, String lastname) {
            return (List<Player>) playerRepo.findByFirstnameOrLastname(firstname, lastname);
        }

        @Override
        public List<Team> getTeamsByPlayerId(Long id) {
            return (List<Team>) teamRepo.findByPlayersId(id);
        }

        @Override
        public List<Team> getTeamsByPlayerIdNot(Long id) {
            return (List<Team>) teamRepo.findByPlayersIdNot(id);
        }


        }


