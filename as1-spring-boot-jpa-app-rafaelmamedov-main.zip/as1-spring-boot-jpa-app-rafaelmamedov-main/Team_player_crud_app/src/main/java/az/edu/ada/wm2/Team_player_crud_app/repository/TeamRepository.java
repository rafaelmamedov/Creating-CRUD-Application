package az.edu.ada.wm2.Team_player_crud_app.repository;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TeamRepository extends JpaRepository<Team, Long> {
    Page<Team> findAll(Pageable pageable);
    List<Team> findAll(Sort sort);

    Iterable<Team> findByPlayersId(Long id);
    Iterable<Team> findByNameAndCountryAndLigaAndTrainerAndMarketvalueAndTotalcups(String name, String country, String liga, String trainer, Long marketvalue, Long totalcups);


    @Query("select t from Team t where t not in " +
            "(select t from Team t left join t.players ply where ply.id = :id)")
    Iterable<Team> findByPlayersIdNot(Long id);

    @Query("select t from Team t where lower(t.trainer) like %:keyword%")
    Iterable<Team> getAllTeamsUsingJPAQuery(@Param("keyword") String keyword);
    @Query("select t from Team t where t.totalcups >150 AND t.marketvalue>980000")
    Iterable<Team> getAllCupsMarketUsingJPAQuery();

    @Query(value = "select * from TEAM where trainer like '%mo%'", nativeQuery = true)
    Iterable<Team> getAllTeamsUsingNativeQuery();

    @Query(value = "select * from TEAM where marketvalue>990000", nativeQuery = true)
    Iterable<Team> getMarketValueUsingNativeQuery();
    @Query(value = "select * from TEAM where country='spanish' AND marketvalue>980000", nativeQuery = true)
    Iterable<Team> getCountryANDMarketValueUsingNativeQuery();
}




