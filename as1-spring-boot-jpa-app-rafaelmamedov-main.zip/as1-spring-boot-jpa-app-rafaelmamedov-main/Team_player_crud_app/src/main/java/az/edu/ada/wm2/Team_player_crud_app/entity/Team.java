package az.edu.ada.wm2.Team_player_crud_app.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.*;
import jakarta.persistence.*;
import jakarta.persistence.Table;

import java.util.HashSet;
import java.util.Set;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity

public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String country;
    private String liga;
    private String trainer;
    private Long marketvalue;
    private Long totalcups;
    @ManyToMany(mappedBy = "team",cascade = CascadeType.ALL)
    private Set<Player> players = new HashSet<>();

    public Team(String name, String country, String liga, String trainer, Long marketvalue, Long totalcups) {
        this.name = name;
        this.country = country;
        this.liga = liga;
        this.trainer = trainer;
        this.marketvalue = marketvalue;
        this.totalcups = totalcups;

    }



    @Override
    public String toString() {
        return "Team: " + this.name + ": " + this.country;
    }


}

