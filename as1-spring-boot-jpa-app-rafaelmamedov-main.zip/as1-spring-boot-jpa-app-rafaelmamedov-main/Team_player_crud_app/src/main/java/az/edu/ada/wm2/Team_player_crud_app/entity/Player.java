package az.edu.ada.wm2.Team_player_crud_app.entity;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.*;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;
    private String firstname;
    private String lastname;
    private String contactmail;
    private String age;
    private Long height;
    private String position;

    @ManyToMany
    @JoinTable(
                name = "player_team_table",
                joinColumns = {@JoinColumn(name="player_id")},
                inverseJoinColumns = {@JoinColumn(name="team_id")}


        )
    private Set<Team> team =new HashSet<>();
    @Override


    public String toString() {
        return "Player: " + firstname + ", " + lastname;
    }


}





