package az.edu.ada.wm2.Team_player_crud_app.repository;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;

import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface PlayerRepository extends JpaRepository<Player, Long> {

        Page<Player> findAll(Pageable pageable);
        List<Player> findAll(Sort sort);





        Iterable<Player> findByFirstnameAndLastnameAndContactmailAndAgeAndHeightAndPosition(String firstname, String lastname, String contactmail, String age, Long height, String position);
        Iterable<Player> findByFirstnameOrLastname(String firstname, String lastname);
        Iterable<Player>findByFirstnameLike(String firstname);



    }