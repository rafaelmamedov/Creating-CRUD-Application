package az.edu.ada.wm2.Team_player_crud_app.service;

import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import az.edu.ada.wm2.Team_player_crud_app.repository.PlayerRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface PlayerService {


    Page<Player> list(int pageNo);

    Player save(Player player);

    Player getById(Long id);
    void deleteById(Long id);

    List<Player> getPlayerByNamesAnd(String firstname, String lastname, String contactmail, String age, Long height, String position);
    List<Player> getPlayerByFirstnames(String firstname);

    List<Player> getPlayerByNamesOr(String firstname, String lastname);


    List<Team> getTeamsByPlayerId(Long id);

    List<Team> getTeamsByPlayerIdNot(Long id);





}

