package az.edu.ada.wm2.Team_player_crud_app;

import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import az.edu.ada.wm2.Team_player_crud_app.service.TeamService;
import az.edu.ada.wm2.Team_player_crud_app.service.impl.TeamServiceİmpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamplayercrudappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamplayercrudappApplication.class, args);
	}
}






