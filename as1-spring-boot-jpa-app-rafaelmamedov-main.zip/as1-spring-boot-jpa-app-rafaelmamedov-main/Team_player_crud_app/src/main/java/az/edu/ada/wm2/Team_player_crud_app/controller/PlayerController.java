package az.edu.ada.wm2.Team_player_crud_app.controller;
import az.edu.ada.wm2.Team_player_crud_app.repository.PlayerRepository;
import az.edu.ada.wm2.Team_player_crud_app.service.TeamService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import az.edu.ada.wm2.Team_player_crud_app.entity.Player;
import az.edu.ada.wm2.Team_player_crud_app.entity.Team;
import az.edu.ada.wm2.Team_player_crud_app.service.PlayerService;
import org.springframework.data.domain.Sort;
import org.springframework.ui.Model;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/player")

public class PlayerController {


    static final Logger LOGGER = LoggerFactory.getLogger(PlayerController.class);

    private PlayerService playerService;
    private TeamService teamService;

    public PlayerController(PlayerService playerService) {
        this.playerService = playerService;
    }

    @GetMapping({"", "/", "/list"})
    public String getPlayers(Model model) {
        return getPlayersByPageNo(model, 1);
    }

    @GetMapping("/page/{no}")
    public String getPlayersByPageNo(Model model, @PathVariable("no") Integer pageNo) {
        Page<Player> playersPage = playerService.list(pageNo);

        model.addAttribute("players", playersPage.getContent());
        model.addAttribute("currentPage", pageNo);
        model.addAttribute("totalPages", playersPage.getTotalPages());
        model.addAttribute("nbElements", playersPage.getNumberOfElements());
        model.addAttribute("totalElements", playersPage.getTotalElements());

        return "player/index";
    }

    @GetMapping("/newPlayer")
    public String createNewPlayer(Model model) {
        model.addAttribute("player", new Player());
        LOGGER.info("createNewPlayer()");
        return "player/new_player";
    }

    @PostMapping("/")
    public String save(@ModelAttribute("player") Player player) {
        playerService.save(player);
        return "redirect:/player/";
    }

    @GetMapping("/{id}")
    public String getPlayer(Model model, @PathVariable Long id) throws Exception {
        model.addAttribute("player", playerService.getById(id));
        return "player/info";
    }

    @GetMapping("/and/{firstname}/{lastname}/{contactmail}/{age}/{height}/{position}")
    public String getPlayerByNameAnd(Model model, @PathVariable String firstname, @PathVariable String lastname,@PathVariable String contactmail,@PathVariable String age,@PathVariable Long height,@PathVariable String position) {

        var player = playerService.getPlayerByNamesAnd(firstname,lastname,contactmail,age,height,position);

        model.addAttribute("players", player);

        return "player/index";
    }
    @GetMapping("/like/{firstname}")
    public String getPlayerByFirstNamelike(Model model, @PathVariable String firstname) {

        var player = playerService.getPlayerByFirstnames(firstname);

        model.addAttribute("players", player);

        return "player/index";
    }

    @GetMapping("/or/{firstname}/{lastname}")
    public String getPlayerByNameOr(Model model, @PathVariable String firstname, @PathVariable String lastname) {
        model.addAttribute("players", playerService.getPlayerByNamesOr(firstname, lastname));

        return "player/index";
    }

    @GetMapping("/{id}/team")
    public String getTeamsByPlayerId(Model model, @PathVariable Long id) {
        model.addAttribute("team", playerService.getTeamsByPlayerId(id));
        return "team/index";
    }

    @GetMapping("/{id}/addTeam")
    public String addTeamPage(Model model, @PathVariable Long id) {

        Player play = playerService.getById(id);
        model.addAttribute("player", play);

        List<Team> allTeams = playerService.getTeamsByPlayerIdNot(id);
        model.addAttribute("team", allTeams);
        return "player/add_team";
    }

    @GetMapping("/delete/{id}")
    public String deletePlayer(@PathVariable Long id) {
        playerService.deleteById(id);
        return "redirect:/player/";
    }

    @GetMapping("/update/{id}")
    public ModelAndView updatePlayer(@PathVariable Long id) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("player/update");
        mv.addObject("player", playerService.getById(id));
        return mv;
    }


    @PostMapping("/addtoteam")
    public String addPlayerToTeam(@RequestParam("playerId") Long playerId,
                                  @RequestParam("teamId") Long teamId) {
        Player player = playerService.getById(playerId);
        Team team = teamService.getById(teamId);
        player.getTeam().add(team);
        playerService.save(player);
        return "redirect:/player/" + playerId; // redirect to the player's details page
    }



}


