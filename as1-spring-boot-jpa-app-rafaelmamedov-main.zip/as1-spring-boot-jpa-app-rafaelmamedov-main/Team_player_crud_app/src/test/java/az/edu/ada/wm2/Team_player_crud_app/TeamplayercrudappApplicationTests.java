package az.edu.ada.wm2.Team_player_crud_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamplayercrudappApplicationTests {

	@Test
	void contextLoads() {
	}

}
